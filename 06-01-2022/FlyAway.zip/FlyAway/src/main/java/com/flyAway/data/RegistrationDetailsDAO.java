package com.flyAway.data;

public interface RegistrationDetailsDAO {
	boolean insertDetails(RegistrationDetails rd);
}
