package com.flyAway.data;

public interface BookingDAO {
	boolean insertBooking(Booking booking);
}
