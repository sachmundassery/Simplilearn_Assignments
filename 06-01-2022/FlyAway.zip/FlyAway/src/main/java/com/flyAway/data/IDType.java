package com.flyAway.data;

public class IDType {
	private String type;
	private int id;

	public String getType() {
		return this.type;
	}

	public int getId() {
		return this.id;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setId(int id) {
		this.id = id;
	}
}
