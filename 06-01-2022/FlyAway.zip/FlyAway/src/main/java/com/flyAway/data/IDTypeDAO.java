package com.flyAway.data;

import java.util.List;

public interface IDTypeDAO {
	
	List<IDType> findAll();
}
