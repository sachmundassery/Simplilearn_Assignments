package com.flyAway.actions;

public interface Action {
	void execute();
}
